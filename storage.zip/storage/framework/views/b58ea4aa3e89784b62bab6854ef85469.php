<section id="header">
    <a href="/admin/dashboard"><span>DownloadLahadaApp</span></a>
    <a href="/"><img src="/assets/img/logo/logo.png" id="logo-link" class="logo-atas" alt="" style="cursor: pointer;"></a>
    
        <ul id="navbar">
            <li><a class="<?php echo e(Request::path() == 'about' ? 'active' : ''); ?> eli" href="/about">TentangLahada</a></li>
            <li><a class="eli" href="https://wa.me/+6285724099673?text=Halo%20min,%20saya%20butuh%20bantuan">Bantuan</a></li>
            <li><a class="eli" href="https://shopee.co.id/campaigns/?page=1">Promo</a></li>
            <li><a class="eli" href="https://shopee.co.id/user/purchase/?type=8">LacakPesanan</a></li>
        </ul>
        <form action="<?php echo e(url('/search')); ?>" class="navbar-form <?php echo e(Auth::check() ? 'logged-in' : ''); ?>">
            <input type="search" placeholder="Cari di LahAda" class="navbar-form-search" name="search" value="<?php echo e(Request::get('search')); ?>" aria-label="search">
            <button class="navbar-form-btn">
                <li><i class="fa-solid fa-magnifying-glass kaca"></i></li>
            </button>
        </form>
        <?php if(auth()->guard()->check()): ?>
            <div class="select" tabindex="0" role="button">
                <div class="text-links">
                    <div class="d-flex gap-2 align-items-center">
                        <img src="<?php echo e(asset('storage/user/' . Auth::user()->foto)); ?>" class="rounded-circle"
                            style="width: 50px;" alt="">
                        <div class="d-flex flex-column text-white">
                            <p class="m-0" style="font-weight: 700; font-size:14px;"><?php echo e(Auth::user()->name); ?>

                            </p>
                            <p class="m-0" style="font-size:12px"><?php echo e(Auth::user()->email); ?></p>
                        </div>
                    </div>
                </div>
                <div class="links-login text-white" id="links-login">
                    <a href="logout_pelanggan" style="text-decoration: none" role="button" tabindex="0">Keluar</a>
                </div>
            </div>
        <?php else: ?>
            <button type="button" class="normall" data-bs-toggle="modal" data-bs-target="#exampleModal">Masuk</button>
            <button type="button" class="normal1" data-bs-toggle="modal" data-bs-target="#registerModal">Daftar</button>
        <?php endif; ?>

<script>
    $(".text-links").click(function(e) {
        e.preventDefault();
        var $linksLogin = $("#links-login");
        if ($linksLogin.hasClass("activeLogin")) {
            $linksLogin.removeClass("activeLogin");
        } else {
            $linksLogin.addClass("activeLogin");
        }
    });
</script>
</section>
<?php /**PATH C:\xampp\htdocs\Lahada\resources\views/pelanggan/componen/navbar.blade.php ENDPATH**/ ?>