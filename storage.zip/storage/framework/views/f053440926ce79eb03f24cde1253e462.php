

<?php $__env->startSection('content'); ?>
<section id="hero">
    <div class="teks">
        <h4>lorem</h4>
        <h2>impsum</h2>
        <h1>dolor sit amet</h1>
        <p>consectetur adipisicing</p>
        <a href="<?php echo e(route('shop')); ?>"><button>Belanja Sekarang</button></a>
    </div>
</section>
    
    <div class="kategori">
        <h2>Kategori</h2>
        <section id="feature" class="section-p1">
                <div class="fe-box">
                    <img src="/assets/img/fitur/china.png" alt="">
                    <h6>Chinese Food</h6>
                </div>
                <div class="fe-box">
                    <img src="/assets/img/fitur/turkey.png" alt="">
                    <h6>Middle food</h6>
                </div>
                <div class="fe-box">
                    <img src="/assets/img/fitur/indonesia.png" alt="">
                    <h6>Indonesia Food</h6>
                </div>
                <div class="fe-box">
                    <img src="/assets/img/fitur/japan.png" alt="">
                    <h6>Jappanese Food</h6>
                </div>
                <div class="fe-box">
                    <img src="/assets/img/fitur/south-korea.png" alt="">
                    <h6>Korean Food</h6>
                </div>
                
                <div class="fe-box">
                    <img src="/assets/img/fitur/pig.png" alt="">
                    <h6>Non Halal</h6>
            </div>
        </section>
    </div>
    
    <section id="product1" class="section-p1">
        <?php if(Auth::check()): ?>
            <h2>Rekomendasi Produk untuk <?php echo e(Auth::user()->name); ?></h2>
        <?php else: ?>
            <h2>Rekomendasi Produk untuk anda</h2>
        <?php endif; ?>
        <div class="pro-container">
            <?php if($data->isEmpty()): ?>
                <h1>Belum ada produk</h1>
            <?php else: ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="pro" onclick="redirectToDetail('<?php echo e(Auth::check()); ?>', '<?php echo e(route('showDetail', $p->id)); ?>')">
                        <img src="<?php echo e(asset('storage/product/' . $p->foto)); ?>" alt="">
                        <div class="des">
                            <span><?php echo e($p->alamat_penjual); ?></span>
                            <h5><?php echo e($p->nama_product); ?></h5>
                            <h4>Rp <?php echo e($p->harga); ?></h4>
                        </div>
                        <img src="<?php echo e($p->halal == 'halal' ? asset('assets/img/halal-haram/halal.png') : asset('assets/img/halal-haram/haram.png')); ?>" alt="" class="halal-logo">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </section>

    <section id="banner" class="section-m1">
        <h4>Selamat Datang di LahAda</h4>
        <h2>Diskon Awal Bulan Hingga 70% Hanya Untuk Mu!!!</h2>
        <button class="normal">Gabung Sekarang</button>
        <h2></h2>
    </section>

    <script>
        function redirectToDetail(isLoggedIn, route) {
            if (isLoggedIn) {
                window.location.href = route;
            } else {
                alert("Harap login untuk mengakses fitur");
            }
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pelanggan.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lahada\resources\views/pelanggan/page/home.blade.php ENDPATH**/ ?>