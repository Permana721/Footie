<footer class="section-p1">
    <div class="col">
        <img src="/assets/img/logo/logo.png" alt="">
        <div class="lp">
            <h4>Layanan Pelanggan</h4>
            <p>Bantuan</p>
            <p>Metode Pembayaran</p>
            <p>Laporkan Bug</p>
            <p>Pengembalian Barang & Dana</p>
        </div>
        <div class="follow">
            <h4>Ikuti Kami</h4>
            <div class="icon">
                <ion-icon name="logo-facebook" onclick="fb()"></ion-icon>
                <ion-icon name="logo-instagram"></ion-icon>
                <ion-icon name="logo-twitter"></ion-icon>
                <ion-icon name="logo-youtube" onclick="yt()"></ion-icon>
            </div>
        </div>
    </div>

    <div class="col">
        <h4>LahAda</h4>
        <a href="">Tentang LahAda</a>
        <a href="">Kebijakan Layanan</a>
        <a href="">kebijakan Privasi</a>
        <a href="">Blog</a>
        <a href="">Mitra LahAda</a>
    </div>

    <div class="col">
        <h4>Akun Saya</h4>
        <a href="">Masuk/Buat Akun</a>
        <a href="">Keranjang Belanja</a>
        <a href="">Lacak Pesanan Saya</a>
        <a href="">Managemen Perangkat</a>
        <a href="">Ubah Alamat Email</a>
    </div>

    <div class="col install">
        <h4>Dapatkan Aplikasi LahAda</h4>
        <p>Install Dari App Store atau Play Store</p>
        <div class="row">
            <img src="/assets/img/bayar/app.jpg" alt="">
            <img src="/assets/img/bayar/play.jpg" alt="" class="play">
        </div>
        <p>Pembayaran </p>
        <img src="/assets/img/bayar/pay.png" alt="" class="bayar">
    </div>
</footer><?php /**PATH C:\xampp\htdocs\Lahada\resources\views/pelanggan/componen/footer.blade.php ENDPATH**/ ?>