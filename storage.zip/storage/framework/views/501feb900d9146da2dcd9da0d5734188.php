

<?php $__env->startSection('content'); ?>
    <h1>Ini Report</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lahada\resources\views/admin/page/report.blade.php ENDPATH**/ ?>