

<?php $__env->startSection('content'); ?>
<body>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section id="prodetails" class="section-p1">
            <div class="single-pro-image">
                <img src="<?php echo e(asset('storage/product/' . $p->foto)); ?>" width="100%" id="MainImg" alt="">
                <div class="small-img-group">
                    <div class="small-img-col">
                        <img src="../img/produk/toppoki.jpg" width="100%" class="small-img" alt="">
                    </div>
                    <div class="small-img-col">
                        <img src="../img/produk/topoki2.jpg" width="100%" class="small-img" alt="">
                    </div>
                    <div class="small-img-col">
                        <img src="../img/produk/halal-topoki.jpg" width="100%" class="small-img" alt="">
                    </div>
                    <div class="small-img-col">
                        <img src="../img/produk/topoki3.jpg" width="100%" class="small-img" alt="">
                    </div>
                </div>
            </div>
        
            <div class="single-pro-details">
                <h6><i class="fa-solid fa-location-dot"></i><?php echo e($p->alamat_penjual); ?></h6>
                <h4><?php echo e($p->nama_product); ?></h4>
                <h2>Rp <?php echo e($p->harga); ?></h2>
                <div class="favorit">
                    <span><i class="fa-solid fa-heart hati"></i> Like</span>
                </div>
                <button class="normal" onclick="window.location.href='<?php echo e($p->link); ?>'">Beli Sekarang</button>
                <h4>Deskripsi Produk</h4>
                    <span>
                        <?php echo e($p->deskripsi); ?>

                    </span>
            </div>
        </section>
    
        
    <div class="comment-section">
        <h5>Komentar (2)</h5>
        <span><?php echo e($p->nama_product); ?></span>
        <div class="post-comment">
            <div class="list">
                <div class="user">
                    <div class="user-image"><img src="../img/image-comment/Ganjar.jpg" alt="image"></div>
                    <div class="user-meta">
                        <div class="name">Homelander</div>
                        <div class="day">10 hari lalu</div>
                    </div>
                </div>
                <div class="comment-post">Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae fuga officiis voluptatibus placeat voluptatem alias ullam.</div>
            </div>
            <div class="list">
                <div class="user">
                    <div class="user-image"><img src="../img/image-comment/ijul.jpg" alt="image"></div>
                    <div class="user-meta">
                        <div class="name">Wolf Thrifting</div>
                        <div class="day">14 hari lalu</div>
                    </div>
                </div>
                <div class="comment-post">Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae fuga officiis voluptatibus placeat voluptatem alias ullam.</div>
            </div>
        </div>
        <div class="comment-box">
            <div class="user">
                <div class="image"><img src="<?php echo e(asset('storage/user/' . Auth::user()->foto)); ?>" alt="image"></div>
                <div class="name"><?php echo e(Auth::user()->name); ?></div>
            </div>
            <form action="" method="post">
                <textarea name="comment" id="" placeholder="Tulis pesan anda"></textarea>
                <button class="comment-submit">Kirim</button>
            </form>
        </div>
    </div>


    <section id="product1" class="section-p1">
        <?php if(Auth::check()): ?>
            <h2>Pilihan Lainnya Untuk <?php echo e(Auth::user()->name); ?></h2>
        <?php else: ?>
            <h2>Rekomendasi Produk untuk anda</h2>
        <?php endif; ?>
        <div class="pro-container">
            <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="pro" onclick="window.location.href='<?php echo e(route('showDetail', $p->id)); ?>'">
                    <img src="<?php echo e(asset('storage/product/' . $p->foto)); ?>" alt="">
                    <div class="des">
                        <span><?php echo e($p->alamat_penjual); ?></span>
                        <h5><?php echo e($p->nama_product); ?></h5>
                        <h4>Rp <?php echo e($p->harga); ?></h4>
                    </div>
                    <img src="<?php echo e($p->halal == 'halal' ? asset('assets/img/halal-haram/halal.png') : asset('assets/img/halal-haram/haram.png')); ?>" alt="" class="halal-logo">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    


    <script>
        var MainImg = document.getElementById("MainImg");
        var smallimg = document.getElementsByClassName("small-img");

        smallimg[0].onclick = function(){
            MainImg.src = smallimg[0].src;
        }
        smallimg[1].onclick = function(){
            MainImg.src = smallimg[1].src;
        }
        smallimg[2].onclick = function(){
            MainImg.src = smallimg[2].src;
        }
        smallimg[3].onclick = function(){
            MainImg.src = smallimg[3].src;
        }
    </script>
    
</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pelanggan.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lahada\resources\views/pelanggan/page/produk.blade.php ENDPATH**/ ?>